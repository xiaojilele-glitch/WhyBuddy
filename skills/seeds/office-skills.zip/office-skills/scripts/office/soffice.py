"""Run LibreOffice (soffice) in headless-friendly mode.

The default path avoids LD_PRELOAD shims. If a sandboxed Linux environment blocks
AF_UNIX sockets, pass --allow-socket-shim to opt into a per-run temporary shim.
"""

from __future__ import annotations

import argparse
import os
import shutil
import socket
import subprocess
import sys
import tempfile
from pathlib import Path


def get_soffice_env(allow_socket_shim: bool = False) -> dict:
    env = os.environ.copy()
    env["SAL_USE_VCLPLUGIN"] = "svp"

    if allow_socket_shim and _needs_shim():
        shim = _build_shim()
        env["LD_PRELOAD"] = str(shim)

    return env


def run_soffice(args: list[str], allow_socket_shim: bool = False, **kwargs) -> subprocess.CompletedProcess:
    env = get_soffice_env(allow_socket_shim=allow_socket_shim)
    soffice_executable = shutil.which("soffice")
    if not soffice_executable:
        raise FileNotFoundError(
            "LibreOffice 'soffice' was not found in PATH. Install LibreOffice or add soffice to PATH."
        )

    return subprocess.run([soffice_executable] + args, env=env, **kwargs)


def _needs_shim() -> bool:
    if os.name == "nt" or not hasattr(socket, "AF_UNIX"):
        return False

    try:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.close()
        return False
    except OSError:
        return True


def _build_shim() -> Path:
    gcc = shutil.which("gcc")
    if not gcc:
        raise RuntimeError(
            "LibreOffice needs an AF_UNIX shim in this environment, but gcc was not found. "
            "Install gcc, rerun with --allow-socket-shim, or run LibreOffice conversion outside this sandbox."
        )

    shim_dir = Path(tempfile.mkdtemp(prefix="office_skills_lo_shim_"))
    src = shim_dir / "lo_socket_shim.c"
    shim = shim_dir / "lo_socket_shim.so"
    src.write_text(_SHIM_SOURCE, encoding="utf-8")

    try:
        subprocess.run(
            [gcc, "-shared", "-fPIC", "-o", str(shim), str(src), "-ldl"],
            check=True,
            capture_output=True,
        )
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(
            "Failed to compile LibreOffice AF_UNIX shim. Install a working C compiler "
            "or run LibreOffice conversion outside this sandboxed environment."
        ) from exc

    return shim


_SHIM_SOURCE = r"""
#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <unistd.h>

static int (*real_socket)(int, int, int);
static int (*real_socketpair)(int, int, int, int[2]);
static int (*real_listen)(int, int);
static int (*real_accept)(int, struct sockaddr *, socklen_t *);
static int (*real_close)(int);
static int (*real_read)(int, void *, size_t);
static int is_shimmed[1024];
static int peer_of[1024];
static int wake_r[1024];
static int wake_w[1024];
static int listener_fd = -1;

__attribute__((constructor))
static void init(void) {
    real_socket     = dlsym(RTLD_NEXT, "socket");
    real_socketpair = dlsym(RTLD_NEXT, "socketpair");
    real_listen     = dlsym(RTLD_NEXT, "listen");
    real_accept     = dlsym(RTLD_NEXT, "accept");
    real_close      = dlsym(RTLD_NEXT, "close");
    real_read       = dlsym(RTLD_NEXT, "read");
    for (int i = 0; i < 1024; i++) {
        peer_of[i] = -1;
        wake_r[i]  = -1;
        wake_w[i]  = -1;
    }
}

int socket(int domain, int type, int protocol) {
    if (domain == AF_UNIX) {
        int fd = real_socket(domain, type, protocol);
        if (fd >= 0) return fd;
        int sv[2];
        if (real_socketpair(domain, type, protocol, sv) == 0) {
            if (sv[0] >= 0 && sv[0] < 1024) {
                is_shimmed[sv[0]] = 1;
                peer_of[sv[0]]    = sv[1];
                int wp[2];
                if (pipe(wp) == 0) {
                    wake_r[sv[0]] = wp[0];
                    wake_w[sv[0]] = wp[1];
                }
            }
            return sv[0];
        }
        errno = EPERM;
        return -1;
    }
    return real_socket(domain, type, protocol);
}

int listen(int sockfd, int backlog) {
    if (sockfd >= 0 && sockfd < 1024 && is_shimmed[sockfd]) {
        listener_fd = sockfd;
        return 0;
    }
    return real_listen(sockfd, backlog);
}

int accept(int sockfd, struct sockaddr *addr, socklen_t *addrlen) {
    if (sockfd >= 0 && sockfd < 1024 && is_shimmed[sockfd]) {
        if (wake_r[sockfd] >= 0) {
            char buf;
            real_read(wake_r[sockfd], &buf, 1);
        }
        errno = ECONNABORTED;
        return -1;
    }
    return real_accept(sockfd, addr, addrlen);
}

int close(int fd) {
    if (fd >= 0 && fd < 1024 && is_shimmed[fd]) {
        int was_listener = (fd == listener_fd);
        is_shimmed[fd] = 0;
        if (wake_w[fd] >= 0) {
            char c = 0;
            write(wake_w[fd], &c, 1);
            real_close(wake_w[fd]);
            wake_w[fd] = -1;
        }
        if (wake_r[fd] >= 0) { real_close(wake_r[fd]); wake_r[fd]  = -1; }
        if (peer_of[fd] >= 0) { real_close(peer_of[fd]); peer_of[fd] = -1; }
        if (was_listener) _exit(0);
    }
    return real_close(fd);
}
"""


def main() -> None:
    parser = argparse.ArgumentParser(description="Run LibreOffice soffice with headless-friendly defaults")
    parser.add_argument("--allow-socket-shim", action="store_true", help="Opt into Linux AF_UNIX LD_PRELOAD shim for restricted sandboxes")
    parser.add_argument("soffice_args", nargs=argparse.REMAINDER, help="Arguments passed to soffice")
    args = parser.parse_args()

    soffice_args = args.soffice_args
    if soffice_args and soffice_args[0] == "--":
        soffice_args = soffice_args[1:]

    try:
        result = run_soffice(soffice_args, allow_socket_shim=args.allow_socket_shim)
    except (FileNotFoundError, RuntimeError) as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)

    sys.exit(result.returncode)


if __name__ == "__main__":
    main()
